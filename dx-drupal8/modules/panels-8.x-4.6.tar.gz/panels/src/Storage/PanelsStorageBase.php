<?php

namespace Drupal\panels\Storage;

use Drupal\Component\Plugin\PluginBase;

abstract class PanelsStorageBase extends PluginBase implements PanelsStorageInterface {
}

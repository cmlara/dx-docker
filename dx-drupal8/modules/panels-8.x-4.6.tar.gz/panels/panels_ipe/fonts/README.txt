Our icon font file (ipeicons.woff) is auto-generated from https://icomoon.io/.

If you wish to add or change an icon in ipeicons.woof, visit
https://icomoon.io/app/#/select and import the selection.json file. You can
then import new SVGs to add to the font from your preferred source.

If IcoMoon ever goes offline, we can move to using the full Google Material
icons font, which is larger but potentially easier to maintain than what we do
now.

<?php

namespace Drupal\panels_ipe\Plugin;


use Drupal\Core\Plugin\PluginBase;

abstract class IPEAccessBase extends PluginBase implements IPEAccessInterface {}

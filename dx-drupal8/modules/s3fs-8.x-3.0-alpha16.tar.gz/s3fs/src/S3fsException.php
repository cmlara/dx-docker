<?php

namespace Drupal\s3fs;

/**
 * Class used to differentiate between known and unknown exception states.
 */
class S3fsException extends \Exception {}

<?php

namespace Drupal\jsonapi\Normalizer\ImpostorFrom\jsonapi_extras;

use Drupal\jsonapi_extras\Normalizer\ResourceObjectNormalizer;

/**
 * Impostor normalizer for ResourceObjectNormalizer.
 */
class ResourceObjectNormalizerImpostor extends ResourceObjectNormalizer {}
